<div class='navbar'>
    <a href="index.php">메인</a>
    <a href="list.php">글목록 보기</a>
    <a href="create.php">글작성하기</a>
    <a href="request.php">요청하기</a>
    <a href="qa.php">Q&A</a>
</div>
<link rel="stylesheet" type="text/css" href="../css/styles.css">