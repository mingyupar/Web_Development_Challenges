<?php
session_start();
include '../config/database.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
?>
<div class='container'>
    <?php include 'header.php'; ?>
    <h2>환영합니다, <?php echo $_SESSION['username']; ?>!</h2>
    <a href='../auth/logout.php'>로그아웃</a>
</div>
<script src="../js/scripts.js"></script>
