<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "board_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("MySQL 연결 실패: " . $conn->connect_error);
}
?>