<?php
session_start();
include '../config/database.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
$sql = "SELECT * FROM posts ORDER BY created_at DESC";
$result = $conn->query($sql);
?>
<div class='container'>
    <?php include 'header.php'; ?>
    <h2>게시판 목록</h2>
    <ul>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <li><a href="view.php?id=<?php echo $row['id']; ?>"><?php echo $row['title']; ?></a></li>
        <?php } ?>
    </ul>
</div>
<script src="../js/scripts.js"></script>
